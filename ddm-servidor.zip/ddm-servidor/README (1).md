# DUELO DOS MARES — Servidor online

Servidor para jogar com amigos (todos contra todos, até 8 jogadores, 10 abates ou 5 minutos).
Não precisa instalar nada além do Node 18+ (sem dependências).

## Como colocar no ar só pelo celular (Render, grátis)

1. Crie uma conta em github.com e um repositório novo (ex.: `duelo-dos-mares`).
2. No repositório: **Add file → Upload files** e envie estes itens mantendo a pasta:
   `server.js`, `package.json` e a pasta `public` com `index.html` dentro.
3. Crie uma conta em render.com (pode entrar com o GitHub).
4. **New → Web Service** → escolha o repositório.
   - Runtime: **Node**
   - Build Command: *(deixe vazio ou `npm install`)*
   - Start Command: `node server.js`
   - Instance type: **Free**
5. Quando terminar, o Render mostra um endereço `https://duelo-dos-mares.onrender.com`.
   **Abra esse endereço no celular** (é o próprio jogo) → toque em **Online** → **Criar sala**.
6. Passe o código de 4 letras para seus amigos. Eles abrem o mesmo endereço → **Online → Entrar**.

Observações:
- No plano grátis o servidor "dorme" após ~15 min sem uso; o primeiro acesso demora até 1 minuto.
- O jogo precisa ser aberto **pelo endereço do servidor**. A versão de visualização do Claude não conecta.
- Teste local: `node server.js` e abra `http://localhost:3000`.

## Limites desta versão
- Anti-trapaça básico (o servidor confere alcance, intervalo de ataque e vida), nível "jogo entre amigos".
- Nome/ID/selo ADM são enviados pelo próprio aparelho e não são verificados pelo servidor.
- Salas somem quando todos saem.

## Variáveis de ambiente (Render → Environment)
- `MP_ACCESS_TOKEN` — chave do Mercado Pago (credenciais de produção). Só é necessária para ligar a Loja de Gemas com Pix. Nunca coloque no código nem mande no chat.
- `PUBLIC_URL` — o endereço do seu servidor (ex.: `https://duelo-dos-mares.onrender.com`), usado para o aviso de pagamento do Mercado Pago.
- `MP_WEBHOOK_SECRET` — (opcional) segredo da notificação do Mercado Pago.
- `ADMIN_KEY` — uma senha sua para ler as denúncias dentro do jogo (Correio, no modo dono).
- `DATA_DIR` — pasta de dados (pedidos e denúncias). No Render grátis o disco é apagado quando o servidor reinicia; para não perder pedidos use um disco persistente.

## Squad
Em Amigos → "Criar sala do squad" a sala aceita até 4 jogadores. Chamada de voz ainda não existe.
