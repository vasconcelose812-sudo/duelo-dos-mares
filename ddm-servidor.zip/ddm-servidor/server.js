/* DUELO DOS MARES — servidor online (sem dependências). Node 18+.
   HTTP: serve public/index.html (o jogo). WebSocket: salas de até 8 jogadores, todos contra todos. */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const payments = require('./payments');
const reports = require('./reports');

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 8;
const KILL_LIMIT = 10;
const MATCH_MS = 5 * 60 * 1000;
const RESPAWN_MS = 3000;
const ARENA_R = 26;
const TICK_MS = 66; // ~15 Hz
const ATK = { l: { d: 14, r: 2.4, cd: 380 }, h: { d: 26, r: 2.8, cd: 900 }, s: { d: 40, r: 4.0, cd: 4500 } };

/* ---------------- HTTP ---------------- */
const INDEX = path.join(__dirname, 'public', 'index.html');
const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api/report')) { reports.handle(req, res); return; }
  if (req.url.startsWith('/api/pix/') || req.url.startsWith('/webhook/mp')) { payments.handle(req, res); return; }
  if (req.url === '/health') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok'); }
  if (req.url === '/' || req.url.startsWith('/?') || req.url === '/index.html') {
    fs.readFile(INDEX, (e, b) => {
      if (e) { res.writeHead(500); return res.end('index.html não encontrado em /public'); }
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' });
      res.end(b);
    });
    return;
  }
  res.writeHead(404); res.end('404');
});

/* ---------------- WebSocket mínimo ---------------- */
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  socket.setNoDelay(true);
  newClient(socket);
});

function frame(op, payload) {
  const len = payload.length;
  let h;
  if (len < 126) h = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([h, payload]);
}

let nextId = 1;
function newClient(socket) {
  const c = { id: nextId++, socket, buf: Buffer.alloc(0), room: null, alive: true, msgs: 0, mt: Date.now(),
    name: 'Pirata', skin: 0, sword: 0, owner: 0, x: 0, z: 0, ry: 0, a: 0, b: 0, iv: 0, hp: 100, kills: 0, deaths: 0, dead: false, cd: {}, aid: -1, ak: '', hs: null, last: Date.now() };
  c.send = (o) => { if (c.alive) try { socket.write(frame(1, Buffer.from(JSON.stringify(o)))); } catch (e) { } };
  socket.on('data', (d) => {
    c.buf = Buffer.concat([c.buf, d]);
    if (c.buf.length > 1 << 20) return kill(c);
    parse(c);
  });
  socket.on('close', () => kill(c));
  socket.on('error', () => kill(c));
}

function parse(c) {
  for (;;) {
    const b = c.buf;
    if (b.length < 2) return;
    const op = b[0] & 15; let len = b[1] & 127, off = 2;
    const masked = (b[1] & 128) !== 0;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (len > 65536) return kill(c);
    const need = off + (masked ? 4 : 0) + len;
    if (b.length < need) return;
    let p = b.slice(off + (masked ? 4 : 0), need);
    if (masked) { const m = b.slice(off, off + 4); p = Buffer.from(p); for (let i = 0; i < p.length; i++) p[i] ^= m[i & 3]; }
    c.buf = b.slice(need);
    if (op === 8) return kill(c);
    if (op === 9) { try { c.socket.write(frame(10, p)); } catch (e) { } continue; }
    if (op === 1) {
      const now = Date.now();
      if (now - c.mt > 1000) { c.mt = now; c.msgs = 0; }
      if (++c.msgs > 90) continue; // anti-flood
      let o; try { o = JSON.parse(p.toString('utf8')); } catch (e) { continue; }
      if (o && typeof o.t === 'string') try { handle(c, o); } catch (e) { console.error(e); }
    }
  }
}

/* ---------------- Salas ---------------- */
const rooms = new Map();
const CH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode() { for (;;) { let s = ''; for (let i = 0; i < 4; i++) s += CH[(Math.random() * CH.length) | 0]; if (!rooms.has(s)) return s; } }
const clean = (s, n) => String(s == null ? '' : s).replace(/[<>&"'`]/g, '').slice(0, n);
const num = (v, lo, hi, d) => { v = +v; return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d; };

function bc(r, o, except) { r.players.forEach((p) => { if (p !== except) p.send(o); }); }
function lobbyInfo(r) {
  return { t: 'lobby', room: r.code, host: r.host, st: r.state,
    players: r.players.map((p) => ({ id: p.id, name: p.name, skin: p.skin, sword: p.sword, owner: p.owner })) };
}
function spawnPoint(i) { const a = (i / MAX_PLAYERS) * Math.PI * 2 + Math.random() * 0.4; return { x: Math.cos(a) * 9, z: Math.sin(a) * 9 }; }

function handle(c, o) {
  if (o.t === 'join') {
    if (c.room) return;
    c.name = clean(o.name, 14) || 'Pirata'; c.skin = num(o.skin, 0, 40, 0) | 0; c.sword = num(o.sword, 0, 40, 0) | 0; c.owner = o.owner ? 1 : 0;
    let r;
    const code = clean(o.room, 4).toUpperCase();
    if (code) {
      r = rooms.get(code);
      if (!r) return c.send({ t: 'err', m: 'Sala ' + code + ' não existe.' });
      if (r.state !== 'lobby') return c.send({ t: 'err', m: 'A partida dessa sala já começou.' });
      if (r.players.length >= (r.max || MAX_PLAYERS)) return c.send({ t: 'err', m: 'Sala cheia (' + (r.max || MAX_PLAYERS) + ').' });
    } else {
      r = { code: newCode(), max: Math.max(2, Math.min(MAX_PLAYERS, num(o.max, 2, 8, 8) | 0)), players: [], host: c.id, state: 'lobby', t0: 0, timer: null, tick: null };
      rooms.set(r.code, r);
    }
    c.room = r; r.players.push(c);
    c.send({ t: 'hello', id: c.id, room: r.code });
    bc(r, lobbyInfo(r));
    return;
  }
  const r = c.room; if (!r) return;
  if (o.t === 'start') {
    if (r.host !== c.id || r.state !== 'lobby') return;
    if (r.players.length < 2) return c.send({ t: 'err', m: 'Precisa de pelo menos 2 jogadores.' });
    startMatch(r); return;
  }
  if (o.t === 'st') {
    if (c.dead) return;
    c.x = num(o.x, -14, 14, c.x); c.z = num(o.z, -14, 14, c.z); c.ry = num(o.ry, -10, 10, c.ry);
    c.a = num(o.a, 0, 9, 0) | 0; c.b = o.b ? 1 : 0; c.iv = o.iv ? 1 : 0; c.last = Date.now();
    return;
  }
  if (o.t === 'hit') {
    if (r.state !== 'play' || c.dead) return;
    const k = ATK[o.k]; if (!k) return;
    const now = Date.now();
    const aid = num(o.aid, 0, 1e9, 0) | 0;
    if (aid !== c.aid || o.k !== c.ak) { // ataque novo: confere o intervalo mínimo
      if ((c.cd[o.k] || 0) > now - k.cd * 0.6) return; // tolerância de rede
      c.cd[o.k] = now; c.aid = aid; c.ak = o.k; c.hs = new Set();
    }
    const v = r.players.find((p) => p.id === o.to);
    if (!v || v === c || v.dead || (c.hs && c.hs.has(v.id))) return;
    if (c.hs) c.hs.add(v.id);
    if (v.iv && now - v.last < 400) { c.send({ t: 'miss', to: v.id }); return; }
    const dx = v.x - c.x, dz = v.z - c.z;
    if (Math.sqrt(dx * dx + dz * dz) > k.r + 1.6) return; // tolerância de latência
    let d = k.d; if (v.b) d = Math.round(d * 0.3);
    v.hp -= d;
    bc(r, { t: 'dmg', to: v.id, from: c.id, d, hp: Math.max(0, v.hp), b: v.b, k: o.k });
    if (v.hp <= 0) {
      v.dead = true; v.deaths++; c.kills++;
      bc(r, { t: 'kill', k: c.id, v: v.id, ks: c.kills, vd: v.deaths });
      setTimeout(() => respawn(r, v), RESPAWN_MS);
      if (c.kills >= KILL_LIMIT) endMatch(r, c.id);
    }
    return;
  }
  if (o.t === 'emo') { bc(r, { t: 'emo', id: c.id, e: num(o.e, 0, 5, 0) | 0 }, c); return; }
  if (o.t === 'leave') { kill(c); return; }
}

function respawn(r, v) {
  if (r.state !== 'play' || !r.players.includes(v)) return;
  const sp = spawnPoint(Math.floor(Math.random() * MAX_PLAYERS));
  v.hp = 100; v.dead = false; v.x = sp.x; v.z = sp.z;
  bc(r, { t: 'resp', id: v.id, x: sp.x, z: sp.z });
}

function startMatch(r) {
  r.state = 'play'; r.t0 = Date.now();
  r.players.forEach((p, i) => { const sp = spawnPoint(i); p.x = sp.x; p.z = sp.z; p.hp = 100; p.kills = 0; p.deaths = 0; p.dead = false; p.cd = {}; });
  bc(r, { t: 'start', limit: KILL_LIMIT, ms: MATCH_MS, players: r.players.map((p) => ({ id: p.id, x: p.x, z: p.z })), lobby: lobbyInfo(r).players });
  r.tick = setInterval(() => {
    bc(r, { t: 'snap', p: r.players.map((p) => ({ id: p.id, x: +p.x.toFixed(2), z: +p.z.toFixed(2), ry: +p.ry.toFixed(2), a: p.a, b: p.b, hp: Math.max(0, p.hp), d: p.dead ? 1 : 0 })) });
  }, TICK_MS);
  r.timer = setTimeout(() => {
    let best = null; r.players.forEach((p) => { if (!best || p.kills > best.kills) best = p; });
    endMatch(r, best ? best.id : 0);
  }, MATCH_MS);
}

function endMatch(r, winner) {
  if (r.state !== 'play') return;
  r.state = 'end'; clearInterval(r.tick); clearTimeout(r.timer);
  bc(r, { t: 'end', w: winner, sc: r.players.map((p) => ({ id: p.id, name: p.name, k: p.kills, d: p.deaths })) });
  setTimeout(() => { // volta para a sala de espera
    if (!rooms.has(r.code)) return;
    r.state = 'lobby'; r.players.forEach((p) => { p.hp = 100; p.dead = false; });
    bc(r, lobbyInfo(r));
  }, 8000);
}

function kill(c) {
  if (!c.alive) return; c.alive = false;
  try { c.socket.destroy(); } catch (e) { }
  const r = c.room; if (!r) return;
  r.players = r.players.filter((p) => p !== c);
  if (!r.players.length) { clearInterval(r.tick); clearTimeout(r.timer); rooms.delete(r.code); return; }
  if (r.host === c.id) r.host = r.players[0].id;
  bc(r, { t: 'left', id: c.id });
  bc(r, lobbyInfo(r));
  if (r.state === 'play' && r.players.length < 2) endMatch(r, r.players[0].id);
}

if (require.main === module) {
  server.listen(PORT, () => console.log('DUELO DOS MARES online na porta ' + PORT));
}
module.exports = { server };
