/* Denúncias de jogadores: gravadas em DATA_DIR/reports.json. Leitura só com ADMIN_KEY. */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dir = () => process.env.DATA_DIR || path.join(__dirname, 'data');
const file = () => path.join(dir(), 'reports.json');
let list = null;
function load() { if (list) return; try { list = JSON.parse(fs.readFileSync(file(), 'utf8')); } catch (e) { list = []; } }
function save() { try { fs.mkdirSync(dir(), { recursive: true }); fs.writeFileSync(file() + '.tmp', JSON.stringify(list)); fs.renameSync(file() + '.tmp', file()); } catch (e) { console.error('[reports]', e.message); } }
const rate = new Map();
function body(req) { return new Promise((ok, no) => { let b = ''; req.on('data', (d) => { b += d; if (b.length > 8000) { req.destroy(); no(new Error('grande')); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } }); req.on('error', no); }); }
function json(res, c, o) { res.writeHead(c, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(o)); }
const clean = (s, n) => String(s == null ? '' : s).replace(/[<>&"'`]/g, '').slice(0, n);
async function handle(req, res) {
  load();
  if (req.method !== 'POST') return json(res, 405, { error: 'método' });
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(), now = Date.now(), r = rate.get(ip);
  if (!r || now - r.t > 60000) rate.set(ip, { t: now, c: 1 }); else if (++r.c > 12) return json(res, 429, { error: 'devagar' });
  let b; try { b = await body(req); } catch (e) { return json(res, 400, { error: 'corpo' }); }
  if (req.url.startsWith('/api/report')) {
    if (req.url.startsWith('/api/reports')) {
      const key = process.env.ADMIN_KEY || '', given = String(b.key || '');
      const ok = key && given.length === key.length && crypto.timingSafeEqual(Buffer.from(given), Buffer.from(key));
      if (!ok) return json(res, 401, { error: 'chave' });
      return json(res, 200, { reports: list.slice(-200).reverse() });
    }
    const target = clean(b.target, 9).replace(/\D/g, ''), from = clean(b.from, 9).replace(/\D/g, '');
    if (target.length !== 9) return json(res, 400, { error: 'id' });
    list.push({ t: now, from, target, why: Math.max(0, Math.min(3, b.why | 0)), text: clean(b.text, 140) });
    if (list.length > 2000) list.splice(0, list.length - 2000);
    save();
    return json(res, 200, { ok: true });
  }
  return json(res, 404, { error: 'rota' });
}
module.exports = { handle };
