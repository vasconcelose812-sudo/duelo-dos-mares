/* DUELO DOS MARES — Loja de Gemas com Pix (Mercado Pago).
   Nada aqui aprova pagamento sozinho: a confirmação só vem da API do provedor
   (consulta direta ao pagamento) e é conferida contra o pedido gravado no servidor. */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PACKS = {
  p1: { id: 'p1', gems: 100, price: 4.99, name: 'Pacote Inicial' },
  p2: { id: 'p2', gems: 550, price: 19.99, name: 'Pacote Médio' },
  p3: { id: 'p3', gems: 1200, price: 39.99, name: 'Pacote Grande' },
  p4: { id: 'p4', gems: 3500, price: 99.99, name: 'Pacote Lendário' }
};
const cents = (n) => Math.round(Number(n) * 100);

const cfg = () => ({
  api: (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, ''),
  token: process.env.MP_ACCESS_TOKEN || '',
  secret: process.env.MP_WEBHOOK_SECRET || '',
  pub: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
  dir: process.env.DATA_DIR || path.join(__dirname, 'data')
});

/* ---------------- armazenamento (arquivo JSON, gravação atômica) ---------------- */
const orders = new Map();
let loaded = false;
function file() { return path.join(cfg().dir, 'orders.json'); }
function load() {
  if (loaded) return; loaded = true;
  try { JSON.parse(fs.readFileSync(file(), 'utf8')).forEach((o) => orders.set(o.id, o)); } catch (e) { /* primeira execução */ }
}
function persist() {
  try {
    fs.mkdirSync(cfg().dir, { recursive: true });
    const tmp = file() + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify([...orders.values()]));
    fs.renameSync(tmp, file());
  } catch (e) { console.error('[pix] não consegui gravar pedidos:', e.message); }
}

/* ---------------- provedor ---------------- */
async function mp(method, p, body, idem) {
  const c = cfg();
  const headers = { Authorization: 'Bearer ' + c.token, 'Content-Type': 'application/json' };
  if (idem) headers['X-Idempotency-Key'] = idem;
  const r = await fetch(c.api + p, { method, headers, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(12000) });
  const t = await r.text(); let j = {};
  try { j = JSON.parse(t); } catch (e) { /* resposta sem JSON */ }
  if (!r.ok) { const err = new Error('provedor HTTP ' + r.status); err.detail = t.slice(0, 300); throw err; }
  return j;
}

const acctOf = (token) => crypto.createHash('sha256').update(String(token) + '|ddm-pix').digest('hex');
const okToken = (t) => typeof t === 'string' && /^[a-f0-9]{32,64}$/.test(t);
const okMail = (m) => typeof m === 'string' && m.length <= 120 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(m);

function pub(o, withPay) {
  const r = { id: o.id, pack: o.pack, name: o.name, gems: o.gems, price: o.price, status: o.status, delivered: !!o.delivered, createdAt: o.createdAt };
  if (withPay) { r.code = o.code; r.qr = o.qr; }
  return r;
}

async function createOrder(acct, packId, email) {
  const pk = PACKS[packId]; if (!pk) throw Object.assign(new Error('pacote inválido'), { http: 400 });
  if (!okMail(email)) throw Object.assign(new Error('e-mail inválido'), { http: 400 });
  let pend = 0;
  for (const o of orders.values()) {
    if (o.acct !== acct || o.status !== 'pending') continue;
    if (o.pack === packId && Date.now() - o.createdAt < 25 * 60 * 1000) return o; // sem pedido duplicado
    pend++;
  }
  if (pend >= 5) throw Object.assign(new Error('muitos pedidos em aberto'), { http: 429 });
  const id = crypto.randomUUID(), c = cfg();
  const body = {
    transaction_amount: pk.price,
    description: 'Duelo dos Mares - ' + pk.name + ' (' + pk.gems + ' gemas)',
    payment_method_id: 'pix',
    payer: { email },
    external_reference: id
  };
  if (c.pub) body.notification_url = c.pub + '/webhook/mp';
  const r = await mp('POST', '/v1/payments', body, id);
  const td = r.point_of_interaction && r.point_of_interaction.transaction_data;
  if (!r.id || !td || !td.qr_code) throw Object.assign(new Error('provedor não devolveu o Pix'), { http: 502 });
  const o = { id, acct, pack: pk.id, name: pk.name, gems: pk.gems, price: pk.price, pid: String(r.id), status: 'pending', delivered: false, createdAt: Date.now(), code: td.qr_code, qr: td.qr_code_base64 || '', chk: 0 };
  orders.set(id, o); persist();
  return o;
}

/* aplica a resposta do provedor ao pedido, conferindo tudo */
function apply(o, r) {
  if (String(r.id) !== o.pid || r.external_reference !== o.id) { console.warn('[pix] pagamento não corresponde ao pedido', o.id); return o; }
  if (r.status === 'approved') {
    if (cents(r.transaction_amount) !== cents(o.price) || (r.payment_method_id && r.payment_method_id !== 'pix')) {
      o.status = 'invalid'; persist(); console.warn('[pix] valor/forma divergente', o.id); return o;
    }
    if (o.status !== 'approved') { o.status = 'approved'; o.approvedAt = Date.now(); persist(); }
  } else if (['cancelled', 'rejected', 'expired'].includes(r.status) && o.status === 'pending') {
    o.status = r.status; persist();
  }
  return o;
}
async function refresh(o) {
  if (o.status !== 'pending') return o;
  if (Date.now() - (o.chk || 0) < 2500) return o;
  o.chk = Date.now();
  return apply(o, await mp('GET', '/v1/payments/' + encodeURIComponent(o.pid)));
}
const mine = (acct) => [...orders.values()].filter((o) => o.acct === acct);

async function claim(acct) {
  const pend = mine(acct).filter((o) => o.status === 'pending').slice(-5);
  await Promise.all(pend.map((o) => refresh(o).catch((e) => console.warn('[pix] consulta falhou:', e.message))));
  return mine(acct).filter((o) => o.status === 'approved' && !o.delivered).map((o) => pub(o, false));
}

/* webhook: só serve de gatilho; a verdade vem de consultar o pagamento no provedor */
function sigOk(req, dataId) {
  const c = cfg(); if (!c.secret) return true;
  const sig = String(req.headers['x-signature'] || ''), rid = String(req.headers['x-request-id'] || '');
  const ts = (/ts=(\d+)/.exec(sig) || [])[1], v1 = (/v1=([a-f0-9]+)/.exec(sig) || [])[1];
  if (!ts || !v1) return false;
  const id = /^[a-z0-9]+$/i.test(dataId) ? String(dataId).toLowerCase() : String(dataId);
  const h = crypto.createHmac('sha256', c.secret).update('id:' + id + ';request-id:' + rid + ';ts:' + ts + ';').digest('hex');
  const a = Buffer.from(h), b = Buffer.from(v1);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------------- HTTP ---------------- */
const rate = new Map();
function limited(ip) {
  const n = Date.now(), r = rate.get(ip);
  if (!r || n - r.t > 60000) { rate.set(ip, { t: n, c: 1 }); return false; }
  return ++r.c > 90;
}
function json(res, code, o) { res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(o)); }
function body(req) {
  return new Promise((ok, no) => {
    let b = '';
    req.on('data', (d) => { b += d; if (b.length > 20000) { req.destroy(); no(new Error('grande')); } });
    req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } });
    req.on('error', no);
  });
}

async function handle(req, res) {
  load();
  const u = new URL(req.url, 'http://x'), p = u.pathname, c = cfg();
  try {
    if (p === '/api/pix/config' && req.method === 'GET') {
      return json(res, 200, { enabled: !!c.token, packs: Object.values(PACKS) });
    }
    if (req.method !== 'POST') return json(res, 405, { error: 'método' });
    const ip = req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress;
    if (p !== '/webhook/mp' && limited(ip)) return json(res, 429, { error: 'devagar' });
    if (!c.token) return json(res, 503, { error: 'pagamentos não configurados' });
    const b = await body(req);

    if (p === '/webhook/mp') {
      const dataId = String((b.data && b.data.id) || u.searchParams.get('data.id') || u.searchParams.get('id') || '');
      if (!dataId) return json(res, 200, { ok: true });
      if (!sigOk(req, dataId)) return json(res, 401, { error: 'assinatura' });
      const o = [...orders.values()].find((x) => x.pid === dataId);
      if (o) { o.chk = 0; await refresh(o).catch((e) => console.warn('[pix] webhook:', e.message)); }
      return json(res, 200, { ok: true });
    }

    if (!okToken(b.token)) return json(res, 400, { error: 'token' });
    const acct = acctOf(b.token);

    if (p === '/api/pix/create') {
      const o = await createOrder(acct, b.pack, b.email);
      return json(res, 200, { order: pub(o, true) });
    }
    if (p === '/api/pix/claim') return json(res, 200, { orders: await claim(acct) });
    if (p === '/api/pix/ack') {
      const o = orders.get(String(b.id));
      if (o && o.acct === acct && o.status === 'approved' && !o.delivered) { o.delivered = true; o.deliveredAt = Date.now(); persist(); }
      return json(res, 200, { ok: true });
    }
    if (p === '/api/pix/history') {
      return json(res, 200, { orders: mine(acct).sort((x, y) => y.createdAt - x.createdAt).slice(0, 50).map((o) => pub(o, false)) });
    }
    return json(res, 404, { error: 'rota' });
  } catch (e) {
    console.error('[pix]', p, e.message, e.detail || '');
    return json(res, e.http || 502, { error: e.http ? e.message : 'falha ao falar com o provedor de pagamentos' });
  }
}

module.exports = { handle, PACKS, _orders: orders };
